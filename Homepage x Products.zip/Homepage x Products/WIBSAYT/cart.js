const products = [
  { id: 1, name: "Canon EOS R8", price: 104998 },
  { id: 2, name: "Canon EOS 90D", price: 46130 },
  { id: 3, name: "Canon EOS 1200D", price: 310759 },
  { id: 4, name: "Canon EOS 80D", price: 40903 },
  { id: 5, name: "Sony Alpha A7", price: 62785 },
  { id: 6, name: "Zhiyun Weebill-S", price: 14378 },
  { id: 7, name: "Zhiyun Smooth Q3", price: 3376 },
  { id: 8, name: "Viltrox AF 20mm f/2.8 Lens (Sony E)", price: 11153 },
  { id: 9, name: "RangePod Smart", price: 7867 },
  { id: 10, name: "Compact Advanced Kit Tripod", price: 5738 },
  { id: 11, name: "Extendable Tripod", price: 2675 },
  { id: 12, name: "Spark Propeller Guard", price: 360 },
  { id: 13, name: "Compact Action Kit Tripod", price: 3474 },
  { id: 14, name: "Karma Grip Handle", price: 5686 },
  { id: 15, name: "Godox AD600Pro II All-in-One Outdoor Flash", price: 4578 },
  { id: 16, name: "Godox AD200Pro II TTL Pocket Flash", price: 3967 },
  { id: 17, name: "Sigma 14mm f/1.4 DG DN Art Lens (Sony E)", price: 93990 },
  { id: 18, name: "Samyang 50mm F1.4 AS UMC", price: 16500 },
  { id: 19, name: "Samyang 300mm F6.3 ED UMC CS", price: 16000 },
  { id: 20, name: ">Black Magic Design CINEURSAMUPROTEF Blackmagic URSA Mini Pro EF Mount", price: 13535 },
  { id: 21, name: "Saramonic Vmic4 Dual-Capsule Camera-Mount Supercardioid Shotgun Microphone", price: 3542 },
  { id: 22, name: "Nicefoto 50cm Quick Release Mini Bowens Mount Softbox", price: 1800 },
  { id: 23, name: "Saramonic BTW Wireless Bluetooth Clip-On Microphone", price: 2747 },
  { id: 24, name: "Apex XPrompter 19 Inches Portable Presidential Teleprompter with Rolling Case", price: 64854 },
  { id: 25, name: "Panasonic HC-X1500 UHD 4K HDMI Pro Camcorder with 24x Zoom", price: 6543 },
  { id: 26, name: "DJI Osmo Action 5 Pro Adventure Combo", price: 27985 },
  { id: 27, name: "Blackmagic Design URSA Mini Pro 4.6K G2 Digital Cinema Camera", price: 462432 },
  { id: 28, name: "Hollyland VenusLiv V2 4K Live Streaming Video Camera", price: 55568 },
  { id: 29, name: "Benro TSL08AS2CSH Slim Tripod Kit with S2CSH Head (Aluminum)", price: 4856 },
  { id: 30, name: "YUNTENG VCT-880 Portable Aluminum Alloy 3-Section Tripod 5kg Capacity", price: 2955 },
];

// --- Cart State ---
let cart = {};

// --- Update Cart Icon Count ---
function updateCartIcon() {
  const count = Object.values(cart).reduce((sum, item) => sum + item.qty, 0);
  $('#cart-count').text(count);
}

// --- Render Cart Modal Content ---
function updateCartModal() {
  const $cartItems = $('#cart-items');
  let total = 0;
  $cartItems.empty();

  if (Object.keys(cart).length === 0) {
    $cartItems.html('<p>Your cart is empty.</p>');
  } else {
    $.each(cart, function(id, item) {
      const itemTotal = item.price * item.qty;
      total += itemTotal;
      const $itemDiv = $(`
        <div class="cart-item-box mb-3 p-3">
          <div class="product-title">${item.name}</div>
          <div class="product-price">Php ${item.price.toLocaleString(undefined, {minimumFractionDigits:2})}</div>
          <div class="cart-qty-row">
            <button class="btn-circle btn-minus" data-id="${item.id}">-</button>
            <span class="cart-qty">${item.qty}</span>
            <button class="btn-circle btn-plus" data-id="${item.id}">+</button>
          </div>
          <div class="cart-total">Total: Php ${(itemTotal).toLocaleString(undefined, {minimumFractionDigits:2})}</div>
          <button class="btn-remove" data-id="${item.id}">Remove</button>
        </div>
      `);
      $cartItems.append($itemDiv);
    });
  }
  // Update total in modal footer
  let $cartTotal = $('#cart-total');
  if ($cartTotal.length === 0) {
    $cartTotal = $('<span id="cart-total" class="mr-auto font-weight-bold"></span>');
    $('.modal-footer').prepend($cartTotal);
  }
  $cartTotal.text(`Total: Php ${total.toLocaleString(undefined, {minimumFractionDigits:2})}`);
}

// --- Add to Cart Button Handler ---
function setupAddToCartButtons() {
  $('.addCart').off('click').on('click', function() {
    const id = parseInt($(this).data('id'));
    const product = products.find(p => p.id === id);
    if (!cart[id]) {
      cart[id] = { ...product, qty: 1 };
    } else {
      cart[id].qty += 1;
    }
    updateCartIcon();
    updateCartModal();
  });
}

// --- Cart Modal Event Delegation for +, -, Remove ---
function setupCartModalEvents() {
  $('#cart-items').off('click').on('click', '.btn-plus, .btn-minus, .btn-remove', function(e) {
    const id = parseInt($(this).data('id'));
    if ($(this).hasClass('btn-plus')) {
      cart[id].qty += 1;
    } else if ($(this).hasClass('btn-minus')) {
      cart[id].qty -= 1;
      if (cart[id].qty <= 0) delete cart[id];
    } else if ($(this).hasClass('btn-remove')) {
      delete cart[id];
    } else {
      return;
    }
    updateCartIcon();
    updateCartModal();
  });
}

// --- Initialize Cart on Page Load ---
$(document).ready(function() {
  setupAddToCartButtons();
  setupCartModalEvents();
  updateCartIcon();
  updateCartModal();
   $('#cartModal').on('show.bs.modal', function () {
    var cartIsEmpty = Object.keys(cart).length === 0;
    if (cartIsEmpty) {
      $('.checkOut').hide();
    } else {
      $('.checkOut').show();
    }
  });
});