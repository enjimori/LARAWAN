<script>
document.addEventListener("DOMContentLoaded", () => {
    const sections = document.querySelectorAll(".info-section, .contact-section");

    sections.forEach(section => {
        const text = section.querySelector(".info-text, .contact-text");

        // Observe when the section comes into view
        const observer = new IntersectionObserver(entries => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    text.classList.add("show");
                    observer.unobserve(entry.target); // Stop observing once it has appeared
                }
            });
        }, { threshold: 0.1 });
        
        observer.observe(section);
    });
});
</script>